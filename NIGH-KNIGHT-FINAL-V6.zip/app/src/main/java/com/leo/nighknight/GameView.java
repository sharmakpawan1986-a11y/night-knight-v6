package com.leo.nighknight;

import android.content.*;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class GameView extends SurfaceView implements Runnable {
    private enum State { INTRO, MENU, PLAYING, PAUSED, OVER }
    private State state = State.INTRO;
    private final SurfaceHolder holder;
    private final SharedPreferences prefs;
    private final SoundManager sound;
    private Thread thread;
    private volatile boolean running;
    private int W,H;
    private float s,introTime,worldTime;
    private final Random rng = new Random(91357);
    private final ArrayList<Platform> platforms = new ArrayList<>();
    private final ArrayList<Enemy> enemies = new ArrayList<>();
    private final ArrayList<Collectible> items = new ArrayList<>();
    private final ArrayList<Particle> particles = new ArrayList<>();
    private final ArrayList<Rock> rocks = new ArrayList<>();
    private final ArrayList<Electric> electrics = new ArrayList<>();
    private final ArrayList<PointF> stars = new ArrayList<>();
    private Player player;
    private float cameraX,generatedX,furthestXReached;
    private int score,coins,starsCount,difficulty=1,highScore;
    private boolean lightning;
    private float lightningTimer,lightningCooldown;
    private RectF start,resume,pause,restart,menu,save,exit,left,right,jump;
    private int leftPointer=-1,rightPointer=-1,jumpPointer=-1;
    private Bitmap leoLogo,gameLogo;
    private static final String PREF="NighKnightData", HIGH="high_score", SAVE="has_save";

    public GameView(Context c){
        super(c);
        holder=getHolder();
        prefs=c.getSharedPreferences(PREF,0);
        highScore=prefs.getInt(HIGH,0);
        sound=new SoundManager(c);
        leoLogo=BitmapFactory.decodeResource(getResources(),R.drawable.logo_leo_final);
        gameLogo=BitmapFactory.decodeResource(getResources(),R.drawable.logo_nigh_knight_final);
        setFocusable(true);
        setClickable(true);
        requestFocus();
        for(int i=0;i<110;i++)stars.add(new PointF(rng.nextFloat(),rng.nextFloat()));
    }

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        W=w;H=h;s=Math.max(.55f,h/1080f);layout();newGame();
    }

    private void layout(){
        float bw=360*s,bh=82*s,gap=28*s,cx=W/2f;
        start=new RectF(cx-bw/2,H*.50f-bh/2,cx+bw/2,H*.50f+bh/2);
        resume=new RectF(cx-bw/2,start.bottom+gap,cx+bw/2,start.bottom+gap+bh);
        menu=new RectF(cx-bw/2,resume.bottom+gap,cx+bw/2,resume.bottom+gap+bh);
        restart=new RectF(cx-bw/2,H*.57f,cx+bw/2,H*.57f+bh);
        save=new RectF(cx-bw/2,H*.48f,cx+bw/2,H*.48f+bh);
        exit=new RectF(cx-bw/2,H*.62f,cx+bw/2,H*.62f+bh);
        pause=new RectF(W-112*s,20*s,W-20*s,112*s);
        float q=24*s,z=210*s;
        left=new RectF(q,H-q-z,q+z,H-q);
        right=new RectF(q+z+22*s,H-q-z,q+2*z+22*s,H-q);
        jump=new RectF(W-q-z,H-q-z,W-q,H-q);
    }

    private void newGame(){
        score=coins=starsCount=0;difficulty=1;cameraX=0;furthestXReached=0;generatedX=0;
        platforms.clear();enemies.clear();items.clear();particles.clear();rocks.clear();electrics.clear();
        player=new Player(190*s,H-310*s,s);
        Platform p=new Platform(0,H-175*s,1450*s,175*s,Platform.TYPE_NORMAL);
        platforms.add(p);generatedX=p.width;generateWorld(3600*s);
        clearTouchPointers();
    }

    private void generateWorld(float target){
        while(generatedX<target){
            int d=difficulty;
            float gap=(95+rng.nextInt(120)+Math.min(d,12)*7)*s;
            float pw=(430+rng.nextInt(300)-Math.min(d,15)*9)*s;
            if(pw<260*s)pw=260*s;
            Platform prev=platforms.get(platforms.size()-1);
            float py=prev.y+(rng.nextInt(161)-80)*s;
            py=Math.max(H*.37f,Math.min(H-150*s,py));
            float r=rng.nextFloat();
            int type=d>=2&&r<.20?Platform.TYPE_MOVING:(d>=3&&r<.34?Platform.TYPE_FAKE:Platform.TYPE_NORMAL);
            Platform p=new Platform(generatedX+gap,py,pw,160*s,type);
            p.moveSpeed=(85+Math.min(d,10)*12)*s;
            p.hasSpikes=type==Platform.TYPE_NORMAL&&d>=2&&rng.nextFloat()<Math.min(.16+d*.025,.46);
            platforms.add(p);
            int n=1+rng.nextInt(4);
            for(int i=1;i<=n;i++){
                float ix=p.x+i*pw/(n+1),iy=py-(70+rng.nextInt(85))*s;
                items.add(new Collectible(ix,iy,rng.nextFloat()<.84?Collectible.TYPE_COIN:Collectible.TYPE_STAR,s));
            }
            if(!p.hasSpikes&&type!=Platform.TYPE_FAKE&&rng.nextFloat()<Math.min(.34+d*.035,.72)){
                int et=Enemy.MOUTH_LINE;
                if(d>=2&&rng.nextFloat()<.58)et=Enemy.MOUTH_TRIANGLE;
                if(d>=4&&rng.nextFloat()<.30)et=Enemy.MOUTH_CIRCLE;
                enemies.add(new Enemy(p.x+pw*.52f,py-62*s,et,s,p));
            }
            if(d>=3&&rng.nextFloat()<Math.min(.12+d*.022,.40))electrics.add(new Electric(p.x+pw*.25f,py-96*s,s));
            if(d>=4&&rng.nextFloat()<Math.min(.08+d*.016,.26))rocks.add(new Rock(p.x+pw*.72f,py-280*s,s));
            generatedX=p.x+pw;
        }
    }

    @Override public void run(){
        long last=System.nanoTime();
        while(running){
            if(!holder.getSurface().isValid()){sleep(10);continue;}
            long now=System.nanoTime();
            float dt=Math.min(.045f,(now-last)/1e9f);last=now;
            update(dt);render();sleep(2);
        }
    }
    private void sleep(long ms){try{Thread.sleep(ms);}catch(Exception ignored){}}

    private void update(float dt){
        if(state==State.INTRO){introTime+=dt;if(introTime>3.15f)state=State.MENU;return;}
        if(state!=State.PLAYING){updateParticles(dt);return;}
        worldTime+=dt;
        difficulty=score/20+1;
        player.update(dt);

        // One-way endless movement: the player can move backward only inside the currently visible area.
        float leftLimit=cameraX+W*.17f;
        if(player.x<leftLimit){player.x=leftLimit;player.vx=Math.max(0,player.vx);}
        if(player.x>furthestXReached)furthestXReached=player.x;
        float desired=Math.max(cameraX,player.x-W*.40f);
        cameraX+=(desired-cameraX)*Math.min(1,12*dt);
        cameraX=Math.max(cameraX,furthestXReached-W*.83f);
        if(cameraX+W*2.6f>generatedX)generateWorld(cameraX+W*3.5f);

        for(Platform p:platforms)p.update(dt);
        boolean grounded=false;
        RectF b=player.getBounds();
        float previousBottom=b.bottom-player.vy*dt;
        for(Platform p:platforms){
            if(!p.visible())continue;
            if(player.vy>=0&&b.right>p.x&&b.left<p.x+p.width&&b.bottom>=p.y&&previousBottom<=p.y+28*s){
                if(p.type==Platform.TYPE_FAKE){
                    p.isBroken=true;player.isGrounded=false;sound.playFall();spawn(player.x+player.width*.5f,p.y,Color.rgb(255,190,70),12);
                }else{
                    player.y=p.y-player.height;player.vy=0;player.isGrounded=true;grounded=true;
                }
            }
            if(p.hasSpikes&&RectF.intersects(b,new RectF(p.x,p.y-25*s,p.x+p.width,p.y+8*s))){gameOver();return;}
        }
        player.isGrounded=grounded;

        for(Enemy e:enemies){
            if(e.support!=null&&!e.support.visible())e.support=null;
            if(e.support!=null)e.update(dt,player.x,e.support.y,true);else e.stopHorizontal();
        }
        for(Electric e:electrics)e.update(dt);
        for(Rock r:rocks)r.update(dt);

        RectF pb=player.getBounds();
        for(Iterator<Collectible>it=items.iterator();it.hasNext();){
            Collectible c=it.next();c.update(dt);
            if(RectF.intersects(c.getBounds(),pb)){
                if(c.type==Collectible.TYPE_COIN){coins++;score++;sound.playCoin();spawn(c.x,c.y,Color.YELLOW,10);}
                else{starsCount++;score+=10;sound.playStar();spawn(c.x,c.y,Color.CYAN,16);}
                it.remove();
            }
        }

        pb=player.getBounds();
        for(Iterator<Enemy>it=enemies.iterator();it.hasNext();){
            Enemy e=it.next();RectF eb=e.getBounds();
            if(RectF.intersects(pb,eb)){
                float oldBottom=pb.bottom-player.vy*dt;
                if(player.vy>0&&oldBottom<=eb.top+eb.height()*.44f){
                    e.hp--;player.y=eb.top-player.height;player.vy=-620*s;sound.playHit();spawn(e.x+e.width/2,eb.top,Color.MAGENTA,12);
                    if(e.hp<=0){score+=5;sound.playPop();spawn(e.x+e.width/2,eb.centerY(),Color.rgb(255,100,170),22);it.remove();}
                }else{gameOver();return;}
            }
        }
        for(Electric e:electrics)if(e.hit(pb)){gameOver();return;}
        for(Rock r:rocks)if(r.hit(pb)){gameOver();return;}

        updateParticles(dt);cleanup();
        lightningCooldown-=dt;
        if(lightningCooldown<=0&&rng.nextFloat()<.018f){lightning=true;lightningTimer=.32f;lightningCooldown=2.1f+rng.nextFloat()*3.8f;}
        if(lightning){lightningTimer-=dt;if(lightningTimer<=0)lightning=false;}
        if(player.y>H+220*s){sound.playFall();gameOver();}
    }

    private void gameOver(){
        if(state==State.OVER)return;
        sound.playGameOver();state=State.OVER;
        if(score>highScore){highScore=score;prefs.edit().putInt(HIGH,highScore).apply();}
        prefs.edit().putBoolean(SAVE,false).apply();clearTouchPointers();
    }

    private void spawn(float x,float y,int color,int n){for(int i=0;i<n;i++)particles.add(new Particle(x,y,color,s));}
    private void updateParticles(float dt){for(Iterator<Particle>it=particles.iterator();it.hasNext();){Particle p=it.next();p.update(dt);if(p.life<=0)it.remove();}}
    private void cleanup(){float cut=cameraX-900*s;platforms.removeIf(p->p.x+p.width<cut);items.removeIf(c->c.x<cut);enemies.removeIf(e->e.x+e.width<cut);rocks.removeIf(r->r.x<cut);electrics.removeIf(e->e.x<cut);}

    private void render(){
        Canvas c=holder.lockCanvas();if(c==null)return;
        drawBackground(c);
        if(state!=State.INTRO){
            c.save();c.translate(-cameraX,0);
            for(Platform p:platforms)p.draw(c,s);
            for(Electric e:electrics)e.draw(c);
            for(Rock r:rocks)r.draw(c);
            for(Collectible i:items)i.draw(c);
            for(Enemy e:enemies)e.draw(c);
            for(Particle p:particles)p.draw(c);
            player.draw(c);
            c.restore();
        }
        drawUI(c);
        holder.unlockCanvasAndPost(c);
    }

    private void drawBackground(Canvas c){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0,0,0,H,Color.rgb(2,8,24),Color.rgb(15,43,78),Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p);p.setShader(null);

        // distant aurora bands
        p.setShader(new RadialGradient(W*.52f,H*.20f,W*.68f,Color.argb(90,54,115,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H*.72f,p);p.setShader(null);

        // moon glow
        float mx=W*.78f,my=H*.22f,mr=82*s;
        p.setShader(new RadialGradient(mx,my,mr*2.25f,Color.argb(110,120,185,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(mx,my,mr*2.25f,p);p.setShader(null);
        p.setColor(Color.rgb(244,246,232));c.drawCircle(mx,my,mr,p);
        p.setColor(Color.argb(45,70,85,105));c.drawCircle(mx-20*s,my-12*s,15*s,p);c.drawCircle(mx+24*s,my+18*s,11*s,p);c.drawCircle(mx-5*s,my+30*s,7*s,p);

        // fixed stars: no frame-to-frame flicker
        for(int i=0;i<stars.size();i++){
            PointF q=stars.get(i);float tw=1.1f+.8f*(float)Math.sin(worldTime*1.5f+i);
            p.setColor(Color.argb((int)(125+70*tw),235,245,255));c.drawCircle(q.x*W,q.y*H*.64f,Math.max(1.2f,1.8f*s)*tw,p);
        }
        drawMountainLayer(c,H*.69f,105*s,.0031f,.0012f,Color.rgb(7,18,40));
        drawMountainLayer(c,H*.77f,70*s,.0050f,.0020f,Color.rgb(9,26,52));
        drawVillage(c,H*.79f);

        if(lightning){
            p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(8*s);
            p.setColor(Color.argb(55,155,220,255));Path glow=new Path();glow.moveTo(mx-50*s,my-25*s);glow.lineTo(mx-10*s,my+8*s);glow.lineTo(mx-38*s,my+45*s);glow.lineTo(mx-3*s,my+72*s);c.drawPath(glow,p);
            p.setStrokeWidth(3*s);p.setColor(Color.WHITE);Path bolt=new Path();bolt.moveTo(mx-50*s,my-25*s);bolt.lineTo(mx-10*s,my+8*s);bolt.lineTo(mx-38*s,my+45*s);bolt.lineTo(mx-3*s,my+72*s);c.drawPath(bolt,p);p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(70,140,220,255));c.drawCircle(mx,my,mr*1.65f,p);
        }
    }

    private void drawMountainLayer(Canvas c,float base,float amp,float f1,float f2,int color){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);Path q=new Path();q.moveTo(0,H);q.lineTo(0,base);
        for(int x=0;x<=W;x+=18){float y=base-(float)(Math.sin((x+cameraX*.10f)*f1)*amp+Math.sin((x-cameraX*.035f)*f2)*amp*.55f);q.lineTo(x,y);}q.lineTo(W,H);q.close();c.drawPath(q,p);
    }

    private void drawVillage(Canvas c,float base){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        for(int i=0;i<6;i++){
            float x=(i*190-((cameraX*.10f)%190))+70;float h=(55+(i%3)*24)*s;float y=base-h;
            p.setColor(Color.rgb(15,31,51));c.drawRect(x,y,x+70*s,base,p);
            Path roof=new Path();roof.moveTo(x-12*s,y);roof.lineTo(x+35*s,y-32*s);roof.lineTo(x+82*s,y);roof.close();c.drawPath(roof,p);
            p.setColor(Color.argb(185,255,187,78));c.drawRect(x+18*s,y+18*s,x+29*s,y+30*s,p);c.drawRect(x+43*s,y+18*s,x+54*s,y+30*s,p);
        }
        p.setColor(Color.argb(130,255,183,70));
        for(int i=0;i<7;i++){float x=(i*150-((cameraX*.16f)%150))+25;c.drawCircle(x,base-42*s,5*s,p);}
    }

    private void drawUI(Canvas c){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        if(state==State.INTRO){
            p.setColor(Color.rgb(2,7,18));c.drawRect(0,0,W,H,p);
            float fade=Math.min(1,Math.min(introTime/.75f,(3.15f-introTime)/.75f));
            p.setAlpha((int)(255*Math.max(0,fade)));
            drawContained(c,leoLogo,new RectF(W*.22f,H*.12f,W*.78f,H*.88f),p);
            return;
        }

        p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.RIGHT);p.setTextSize(23*s);
        c.drawText("HIGH  "+highScore,W-24*s,40*s,p);

        if(state==State.MENU){
            drawGameLogo(c,new RectF(W*.05f,H*.025f,W*.95f,H*.40f));
            button(c,start,"START",Color.rgb(22,130,190));
            if(prefs.getBoolean(SAVE,false))button(c,resume,"RESUME",Color.rgb(34,61,100));
            p.setTextAlign(Paint.Align.CENTER);p.setTextSize(17*s);p.setColor(Color.argb(205,225,240,255));
            c.drawText("ENDLESS NIGHT  •  RUN  •  JUMP  •  SURVIVE",W/2f,H*.91f,p);
        }else if(state==State.PLAYING){
            p.setTextAlign(Paint.Align.LEFT);p.setTextSize(22*s);
            c.drawText("SCORE "+score+"   COINS "+coins+"   STARS "+starsCount,24*s,38*s,p);
            p.setTextSize(18*s);p.setColor(Color.argb(225,205,225,255));c.drawText("DIFFICULTY "+difficulty,24*s,64*s,p);
            button(c,pause,"Ⅱ",Color.rgb(18,34,61));
            control(c,left,"‹");control(c,right,"›");control(c,jump,"↑");
        }else if(state==State.PAUSED){
            overlay(c,"PAUSED");button(c,resume,"RESUME",Color.rgb(22,130,190));button(c,save,"SAVE GAME",Color.rgb(34,61,100));button(c,exit,"EXIT",Color.rgb(66,74,91));
        }else{
            overlay(c,"GAME OVER");p.setTextAlign(Paint.Align.CENTER);p.setTextSize(27*s);p.setColor(Color.WHITE);
            c.drawText("SCORE "+score+"   COINS "+coins+"   STARS "+starsCount,W/2f,H*.39f,p);
            button(c,restart,"RESTART",Color.rgb(22,130,190));button(c,menu,"MAIN MENU",Color.rgb(34,61,100));
        }
    }

    private void drawGameLogo(Canvas c,RectF dst){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);drawContained(c,gameLogo,dst,p);
    }
    private void drawContained(Canvas c,Bitmap b,RectF dst,Paint p){
        if(b==null)return;float scale=Math.min(dst.width()/b.getWidth(),dst.height()/b.getHeight());
        float dw=b.getWidth()*scale,dh=b.getHeight()*scale;float l=dst.centerX()-dw/2f,t=dst.centerY()-dh/2f;
        c.drawBitmap(b,null,new RectF(l,t,l+dw,t+dh),p);
    }
    private void overlay(Canvas c,String text){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.argb(195,0,0,0));c.drawRect(0,0,W,H,p);
        p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(66*s);p.setColor(Color.WHITE);c.drawText(text,W/2f,H*.24f,p);
    }
    private void button(Canvas c,RectF r,String text,int color){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(r.left,r.top,r.left,r.bottom,Color.argb(70,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(r.left,r.top+6*s,r.right,r.bottom+6*s),18*s,18*s,p);p.setShader(null);
        p.setColor(color);c.drawRoundRect(r,18*s,18*s,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2*s);p.setColor(Color.argb(150,180,235,255));c.drawRoundRect(r,18*s,18*s,p);p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(text.length()>8?21*s:29*s);p.setColor(Color.WHITE);c.drawText(text,r.centerX(),r.centerY()+10*s,p);
    }
    private void control(Canvas c,RectF r,String text){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(r.centerX(),r.centerY(),r.width()*.62f,Color.argb(120,50,175,255),Color.argb(15,20,50,100),Shader.TileMode.CLAMP));c.drawCircle(r.centerX(),r.centerY(),r.width()*.64f,p);p.setShader(null);
        p.setColor(Color.argb(205,10,31,61));c.drawRoundRect(r,30*s,30*s,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3*s);p.setColor(Color.rgb(78,202,255));c.drawRoundRect(r,30*s,30*s,p);p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(text.equals("↑")?62*s:66*s);p.setColor(Color.WHITE);c.drawText(text,r.centerX(),r.centerY()+22*s,p);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        int action=e.getActionMasked(),idx=e.getActionIndex(),pid=e.getPointerId(idx);
        float x=e.getX(idx),y=e.getY(idx);
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            requestDisallowInterceptTouchEvent(true);
            if(state==State.MENU){
                if(start.contains(x,y)){newGame();state=State.PLAYING;}
                else if(prefs.getBoolean(SAVE,false)&&resume.contains(x,y)){load();state=State.PLAYING;}
            }else if(state==State.PLAYING){
                if(pause.contains(x,y)){state=State.PAUSED;clearTouchPointers();}
                else if(left.contains(x,y)&&leftPointer==-1){leftPointer=pid;player.moveLeft=true;}
                else if(right.contains(x,y)&&rightPointer==-1){rightPointer=pid;player.moveRight=true;}
                else if(jump.contains(x,y)&&jumpPointer==-1){jumpPointer=pid;if(player.jump())sound.playJump();}
            }else if(state==State.PAUSED){
                if(resume.contains(x,y))state=State.PLAYING;
                else if(save.contains(x,y)){save();state=State.MENU;}
                else if(exit.contains(x,y))state=State.MENU;
            }else if(state==State.OVER){
                if(restart.contains(x,y)){newGame();state=State.PLAYING;}
                else if(menu.contains(x,y))state=State.MENU;
            }
            return true;
        }
        if(action==MotionEvent.ACTION_POINTER_UP||action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
            if(pid==leftPointer){leftPointer=-1;if(player!=null)player.moveLeft=false;}
            if(pid==rightPointer){rightPointer=-1;if(player!=null)player.moveRight=false;}
            if(pid==jumpPointer)jumpPointer=-1;
            if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)clearTouchPointers();
            return true;
        }
        // Deliberately keep a button latched to its pointer during ACTION_MOVE.
        // This prevents tiny finger movements from randomly cancelling controls.
        return true;
    }

    private void clearTouchPointers(){leftPointer=rightPointer=jumpPointer=-1;if(player!=null){player.moveLeft=false;player.moveRight=false;}}
    private void save(){prefs.edit().putBoolean(SAVE,true).putInt("save_score",score).putInt("save_coins",coins).putInt("save_stars",starsCount).putInt("save_difficulty",difficulty).putFloat("save_px",player.x).putFloat("save_py",player.y).putFloat("save_vy",player.vy).putFloat("save_camx",cameraX).apply();}
    private void load(){
        score=prefs.getInt("save_score",0);coins=prefs.getInt("save_coins",0);starsCount=prefs.getInt("save_stars",0);difficulty=score/20+1;cameraX=Math.max(0,prefs.getFloat("save_camx",0));
        player=new Player(Math.max(cameraX+W*.18f,prefs.getFloat("save_px",190*s)),prefs.getFloat("save_py",H-310*s),s);player.vy=prefs.getFloat("save_vy",0);generatedX=0;
        platforms.clear();enemies.clear();items.clear();rocks.clear();electrics.clear();Platform p=new Platform(0,H-175*s,1450*s,175*s,Platform.TYPE_NORMAL);platforms.add(p);generatedX=p.width;generateWorld(Math.max(3600*s,cameraX+W*3.2f));clearTouchPointers();
    }
    public void resume(){if(running)return;running=true;thread=new Thread(this,"NighKnightLoop");thread.start();}
    public void pause(){running=false;Thread t=thread;thread=null;if(t!=null&&t!=Thread.currentThread())try{t.join(500);}catch(Exception ignored){}}
    @Override protected void onDetachedFromWindow(){pause();sound.release();super.onDetachedFromWindow();}

    private class Rock{
        float x,y,vy;final float size;boolean active=true;
        Rock(float x,float y,float s){this.x=x;this.y=y;size=20*s;}
        void update(float dt){if(y<H+220*size){vy+=1200*dt;y+=vy*dt;}}
        boolean hit(RectF b){if(!active)return false;RectF r=new RectF(x-size,y-size,x+size,y+size);if(RectF.intersects(r,b)){active=false;spawn(x,y,Color.LTGRAY,14);return true;}return false;}
        void draw(Canvas c){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setShader(new RadialGradient(x-size*.3f,y-size*.3f,size,Color.rgb(195,205,220),Color.rgb(70,80,98),Shader.TileMode.CLAMP));c.drawCircle(x,y,size,p);p.setShader(null);}
    }
    private class Electric{
        float x,y;final float size;float phase;
        Electric(float x,float y,float s){this.x=x;this.y=y;size=s;}
        void update(float dt){phase+=dt*7;}
        boolean hit(RectF b){return RectF.intersects(b,new RectF(x-size*1.15f,y-size*1.85f,x+size*1.15f,y+size*1.85f));}
        void draw(Canvas c){
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setShader(new RadialGradient(x,y,size*2.2f,Color.argb(105,65,245,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(x,y,size*2.2f,p);p.setShader(null);
            p.setColor(Color.rgb(91,239,255));c.drawRoundRect(x-size*.22f,y-size*1.7f,x+size*.22f,y+size*1.7f,3*s,3*s,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3*s);p.setColor(Color.WHITE);Path q=new Path();q.moveTo(x-size,y-size*1.5f);q.lineTo(x+size*.7f,y-size*.45f);q.lineTo(x-size*.4f,y+.15f*size);q.lineTo(x+size,y+size*1.5f);c.drawPath(q,p);p.setStyle(Paint.Style.FILL);
        }
    }
}
