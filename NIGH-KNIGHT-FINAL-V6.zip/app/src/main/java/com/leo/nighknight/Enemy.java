package com.leo.nighknight;
import android.graphics.*;

public class Enemy {
    public static final int MOUTH_LINE=1,MOUTH_TRIANGLE=2,MOUTH_CIRCLE=3;
    public float x,y,width,height,vx,vy; public int mouthType,hp; public Platform support;
    private final float scale; private float anim;
    public Enemy(float x,float y,int type,float s){this.x=x;this.y=y;mouthType=type;hp=type;scale=s;width=66*s;height=62*s;}
    public Enemy(float x,float y,int type,float s,Platform platform){this(x,y,type,s);this.support=platform;}
    public void update(float dt,float px,float groundY,boolean onPlatform){
        anim+=dt;
        if(support==null)return;
        float left=support.x+3*scale, right=support.x+support.width-width-3*scale;
        float speed=(78+mouthType*24)*scale;
        boolean playerOnRight=px>x;
        // Enemies chase only while the player is on the same platform zone; otherwise they patrol.
        float target=playerOnRight?speed:-speed;
        if(Math.abs(px-x)>90*scale) vx += (target-vx)*Math.min(1,5*dt);
        else vx *= Math.max(0,1-7*dt);
        float nx=x+vx*dt;
        // Hard edge stop: enemy never steps into a gap.
        if(nx<left){x=left;vx=Math.abs(vx)*0.25f;}
        else if(nx>right){x=right;vx=-Math.abs(vx)*0.25f;}
        else x=nx;
        y=support.y-height; vy=0;
    }
    public void stopHorizontal(){vx=0;}
    public RectF getBounds(){return new RectF(x+5*scale,y+4*scale,x+width-5*scale,y+height);}
    public void draw(Canvas c){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        float bob=(float)Math.sin(anim*7)*1.2f*scale;
        int body=mouthType==1?Color.rgb(255,118,72):mouthType==2?Color.rgb(242,76,132):Color.rgb(164,91,235);
        // glow
        p.setShader(new RadialGradient(x+width/2,y+height/2,45*scale,Color.argb(65,255,120,190),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(x+width/2,y+height/2,45*scale,p);p.setShader(null);
        p.setColor(Color.argb(65,0,0,0));c.drawOval(x-4*scale,y+height-2*scale,x+width+4*scale,y+height+8*scale,p);
        p.setColor(body);c.drawRoundRect(x,y+bob,x+width,y+height+bob,16*scale,16*scale,p);
        p.setColor(Color.rgb(255,238,220));c.drawCircle(x+18*scale,y+21*scale+bob,9*scale,p);c.drawCircle(x+48*scale,y+21*scale+bob,9*scale,p);
        p.setColor(Color.rgb(25,25,35));c.drawCircle(x+18*scale,y+21*scale+bob,3*scale,p);c.drawCircle(x+48*scale,y+21*scale+bob,3*scale,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3*scale);p.setColor(Color.WHITE);
        float my=y+42*scale+bob;
        if(mouthType==MOUTH_LINE)c.drawLine(x+17*scale,my,x+49*scale,my,p);
        else if(mouthType==MOUTH_TRIANGLE){Path q=new Path();q.moveTo(x+18*scale,my);q.lineTo(x+33*scale,my+12*scale);q.lineTo(x+50*scale,my);q.close();c.drawPath(q,p);}
        else c.drawCircle(x+33*scale,my,8*scale,p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(150,255,255,255));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(13*scale);p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(""+hp,x+width/2,y-7*scale,p);
    }
}
