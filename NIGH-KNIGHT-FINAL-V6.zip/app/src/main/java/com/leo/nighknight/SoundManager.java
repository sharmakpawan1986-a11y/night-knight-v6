package com.leo.nighknight;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

/** Optional SFX layer. It is intentionally silent until real audio resources are added. */
public class SoundManager {
    private final SoundPool soundPool;
    public SoundManager(Context context) {
        AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        soundPool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build();
    }
    public void playJump(){} public void playCoin(){} public void playStar(){} public void playHit(){}
    public void playPop(){} public void playElec(){} public void playFall(){} public void playGameOver(){}
    public void release(){soundPool.release();}
}
