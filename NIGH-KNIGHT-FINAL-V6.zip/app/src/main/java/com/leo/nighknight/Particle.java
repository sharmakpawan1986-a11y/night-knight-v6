package com.leo.nighknight;
import android.graphics.*;
public class Particle {public float x,y,vx,vy;public int color;public float life=1f;private float scale;public Particle(float x,float y,int color,float s){this.x=x;this.y=y;this.color=color;scale=s;vx=((float)Math.random()-.5f)*400*s;vy=((float)Math.random()-.5f)*400*s;}public void update(float dt){x+=vx*dt;y+=vy*dt;life-=dt*2.5f;}public void draw(Canvas c){if(life<=0)return;Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setAlpha((int)(life*255));c.drawCircle(x,y,5*scale,p);}}
