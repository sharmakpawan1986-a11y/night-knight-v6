package com.leo.nighknight;

import android.graphics.*;

public class Player {
    public float x,y,width,height,vx,vy;
    public boolean isGrounded, moveLeft, moveRight;
    private final float scale;
    private float animTime;

    public Player(float startX,float startY,float s){
        x=startX; y=startY; scale=s; width=76*s; height=108*s;
    }

    public void update(float dt){
        animTime += dt;
        float target=0;
        if(moveLeft && !moveRight) target=-410*scale;
        else if(moveRight && !moveLeft) target=410*scale;
        float accel=isGrounded?2600*scale:1700*scale;
        if(target!=0) vx += Math.max(-accel*dt,Math.min(accel*dt,target-vx));
        else vx *= Math.max(0,1-12*dt);
        vy += 1850*scale*dt;
        x += vx*dt; y += vy*dt;
    }

    public boolean jump(){
        if(isGrounded){ vy=-820*scale; isGrounded=false; return true; }
        return false;
    }

    public RectF getBounds(){
        return new RectF(x+14*scale,y+8*scale,x+width-14*scale,y+height-3*scale);
    }

    public void draw(Canvas c){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStrokeCap(Paint.Cap.ROUND);
        float run=Math.min(1f,Math.abs(vx)/(410*scale));
        float phase=animTime*14;
        float stride=isGrounded ? (float)Math.sin(phase)*10*scale*run : 0;
        float bob=isGrounded ? (float)Math.abs(Math.sin(phase))*1.6f*scale*run : 0;
        float yy=y+bob;

        // soft contact shadow
        p.setShader(new RadialGradient(x+width*.5f,y+height+3*scale,34*scale,
                Color.argb(95,0,0,0),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawOval(x-18*scale,y+height-3*scale,x+width+18*scale,y+height+13*scale,p);
        p.setShader(null);

        // scarf behind body
        p.setColor(Color.rgb(226,43,65));
        Path scarf=new Path();
        float flap=(float)Math.sin(animTime*9)*12*scale;
        scarf.moveTo(x+22*scale,yy+27*scale);
        scarf.cubicTo(x+4*scale,yy+20*scale,x-12*scale,yy+14*scale+flap,x-31*scale,yy+34*scale+flap);
        scarf.lineTo(x-22*scale,yy+43*scale+flap);
        scarf.cubicTo(x-8*scale,yy+33*scale,x+8*scale,yy+34*scale,x+24*scale,yy+35*scale);
        scarf.close(); c.drawPath(scarf,p);

        // rear sword, visual only
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(7*scale);
        p.setColor(Color.rgb(190,205,225));
        c.drawLine(x+50*scale,yy+69*scale,x+72*scale,yy+38*scale,p);
        p.setStrokeWidth(9*scale); p.setColor(Color.rgb(80,48,42));
        c.drawLine(x+48*scale,yy+70*scale,x+56*scale,yy+60*scale,p);
        p.setStyle(Paint.Style.FILL);

        // legs with boots
        p.setColor(Color.rgb(13,18,31));
        float l1=isGrounded?stride:0, l2=isGrounded?-stride:0;
        Path leg1=new Path();
        leg1.moveTo(x+22*scale,yy+69*scale); leg1.lineTo(x+35*scale,yy+69*scale);
        leg1.lineTo(x+31*scale+l1,yy+94*scale); leg1.lineTo(x+15*scale+l1,yy+94*scale); leg1.close(); c.drawPath(leg1,p);
        Path leg2=new Path();
        leg2.moveTo(x+43*scale,yy+69*scale); leg2.lineTo(x+57*scale,yy+69*scale);
        leg2.lineTo(x+62*scale+l2,yy+94*scale); leg2.lineTo(x+46*scale+l2,yy+94*scale); leg2.close(); c.drawPath(leg2,p);
        p.setColor(Color.rgb(30,38,57));
        c.drawRoundRect(x+10*scale+l1,yy+90*scale,x+34*scale+l1,yy+99*scale,5*scale,5*scale,p);
        c.drawRoundRect(x+43*scale+l2,yy+90*scale,x+67*scale+l2,yy+99*scale,5*scale,5*scale,p);

        // torso silhouette
        p.setColor(Color.rgb(18,25,40));
        c.drawRoundRect(x+13*scale,yy+35*scale,x+63*scale,yy+73*scale,15*scale,15*scale,p);
        // armor folds
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2*scale); p.setColor(Color.rgb(58,72,94));
        c.drawLine(x+20*scale,yy+43*scale,x+55*scale,yy+65*scale,p);
        c.drawLine(x+54*scale,yy+42*scale,x+24*scale,yy+67*scale,p);
        p.setStyle(Paint.Style.FILL);
        // belt and pouches
        p.setColor(Color.rgb(66,72,90)); c.drawRect(x+13*scale,yy+62*scale,x+63*scale,yy+68*scale,p);
        p.setColor(Color.rgb(45,50,65)); c.drawRoundRect(x+15*scale,yy+65*scale,x+27*scale,yy+75*scale,3*scale,3*scale,p); c.drawRoundRect(x+49*scale,yy+65*scale,x+61*scale,yy+75*scale,3*scale,3*scale,p);

        // arms
        p.setColor(Color.rgb(21,29,45));
        float arm= isGrounded ? (float)Math.sin(phase)*7*scale*run : -3*scale;
        c.save(); c.rotate(arm, x+15*scale, yy+43*scale);
        c.drawRoundRect(x+6*scale,yy+39*scale,x+19*scale,yy+69*scale,7*scale,7*scale,p); c.restore();
        c.save(); c.rotate(-arm, x+61*scale, yy+43*scale);
        c.drawRoundRect(x+57*scale,yy+39*scale,x+70*scale,yy+69*scale,7*scale,7*scale,p); c.restore();

        // head and hood
        p.setColor(Color.rgb(10,15,27)); c.drawCircle(x+38*scale,yy+27*scale,27*scale,p);
        p.setColor(Color.rgb(24,31,48));
        Path hood=new Path(); hood.moveTo(x+12*scale,yy+30*scale); hood.quadTo(x+13*scale,yy+5*scale,x+38*scale,yy+5*scale); hood.quadTo(x+63*scale,yy+7*scale,x+64*scale,yy+31*scale); hood.lineTo(x+56*scale,yy+43*scale); hood.lineTo(x+20*scale,yy+43*scale); hood.close(); c.drawPath(hood,p);
        // face opening
        p.setColor(Color.rgb(191,139,111)); c.drawOval(x+18*scale,yy+21*scale,x+58*scale,yy+43*scale,p);
        p.setColor(Color.rgb(7,11,20)); c.drawRect(x+17*scale,yy+22*scale,x+59*scale,yy+31*scale,p);
        // eyes
        p.setColor(Color.WHITE); c.drawOval(x+23*scale,yy+25*scale,x+33*scale,yy+31*scale,p); c.drawOval(x+43*scale,yy+25*scale,x+53*scale,yy+31*scale,p);
        p.setColor(Color.rgb(18,30,48)); c.drawCircle(x+28*scale,yy+28*scale,2.5f*scale,p); c.drawCircle(x+48*scale,yy+28*scale,2.5f*scale,p);
        // headband
        p.setColor(Color.rgb(225,39,60)); c.drawRect(x+13*scale,yy+13*scale,x+63*scale,yy+20*scale,p);
        p.setStrokeWidth(3*scale); p.setStyle(Paint.Style.STROKE); p.setColor(Color.rgb(255,100,115)); c.drawLine(x+19*scale,yy+16*scale,x+56*scale,yy+16*scale,p); p.setStyle(Paint.Style.FILL);
    }
}
