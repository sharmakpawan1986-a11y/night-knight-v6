package com.leo.nighknight;
import android.graphics.*;
public class Platform {
 public static final int TYPE_NORMAL=0,TYPE_MOVING=1,TYPE_FAKE=2;
 public float x,y,width,height,moveSpeed=120,fallTimer; public int type,direction=1; public boolean hasSpikes,isBroken;
 private final float startX; private final float range=190;
 public Platform(float x,float y,float w,float h,int type){this.x=x;this.y=y;startX=x;width=w;height=h;this.type=type;}
 public void update(float dt){
  if(type==TYPE_MOVING&&!isBroken){x+=moveSpeed*direction*dt;if(x>startX+range){x=startX+range;direction=-1;}if(x<startX-range){x=startX-range;direction=1;}}
  if(isBroken&&type==TYPE_FAKE){fallTimer+=dt;y+=760*dt;}
 }
 public boolean visible(){return !(isBroken&&type==TYPE_FAKE&&fallTimer>1.1f);}
 public void draw(Canvas c,float s){
  if(!visible())return; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
  // soft platform glow
  int glow=type==TYPE_MOVING?Color.rgb(70,160,255):type==TYPE_FAKE?Color.rgb(255,170,70):Color.rgb(48,130,175);
  p.setShader(new LinearGradient(0,y,0,y+height,Color.rgb(24,53,94),Color.rgb(10,25,51),Shader.TileMode.CLAMP));
  c.drawRoundRect(x,y,x+width,y+height,14*s,14*s,p);p.setShader(null);
  p.setColor(Color.argb(75,glow==0?255:100,220,255));c.drawRoundRect(x-5*s,y-5*s,x+width+5*s,y+12*s,10*s,10*s,p);
  p.setColor(glow);c.drawRoundRect(x,y,x+width,y+9*s,5*s,5*s,p);
  // grass / rim
  p.setColor(Color.rgb(87,205,126));c.drawRoundRect(x+3*s,y-4*s,x+width-3*s,y+4*s,4*s,4*s,p);
  p.setColor(Color.rgb(39,105,78));
  for(float xx=x+12*s;xx<x+width-8*s;xx+=24*s)c.drawRect(xx,y+11*s,xx+16*s,y+16*s,p);
  if(type==TYPE_MOVING){p.setColor(Color.argb(150,140,205,255));c.drawCircle(x+width/2,y+height*.55f,6*s,p);}
  if(type==TYPE_FAKE){p.setColor(Color.argb(180,255,214,100));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2*s);for(int i=0;i<4;i++){float xx=x+width*(i+.5f)/4f;Path q=new Path();q.moveTo(xx-8*s,y+25*s);q.lineTo(xx,y+38*s);q.lineTo(xx+7*s,y+25*s);c.drawPath(q,p);}p.setStyle(Paint.Style.FILL);}
  if(hasSpikes){p.setColor(Color.rgb(224,238,255));Path q=new Path();float sw=29*s;for(int i=0;i<(int)(width/sw);i++){float sx=x+i*sw;q.reset();q.moveTo(sx,y);q.lineTo(sx+sw/2,y-25*s);q.lineTo(sx+sw,y);q.close();c.drawPath(q,p);}}
 }
}
